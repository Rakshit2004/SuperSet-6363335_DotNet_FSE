**Cleanup \& Push to Remote**



Commands to Execute in Git Bash:



1. cd GitDemo
2. git status
3. git branch
4. git pull origin master
5. git push origin master
